declare module '@/public/qqmap-wx-jssdk.js';
