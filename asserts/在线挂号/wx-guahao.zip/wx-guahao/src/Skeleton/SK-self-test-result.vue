<template>
  <view class="skeleton-view">
    <view class="skeleton-global sk-result-title"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-du"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-title"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
    <view class="skeleton-global sk-result-label"></view>
  </view>
</template>

<script setup lang="ts">

</script>

<style scoped>
.sk-result-title{
  margin: 20rpx;
  height: 60rpx;
  width: 200rpx;
}
.sk-result-label{
  margin: 20rpx;
  height: 60rpx;
}
.sk-result-du{
  margin: 20rpx;
  height: 80rpx;
  width: 300rpx;
}

</style>