// 健康自测的分享数据

export let TEST = [
	{
		type: '001',
		name: '抑郁测评专业版',
		share_title: '抑郁测评专业版,你是不开心还是真抑郁',
		share_path: '/pages/self-test/topic?type=001&name=抑郁测评专业版',
		share_url:
			'https://diancan-1252107261.cos.accelerate.myqcloud.com/yiliao/F-yiyu.png',
	},
	{
		type: '002',
		name: '男性功能测试',
		share_title: '五个办法判断自身性功能',
		share_path: '/pages/self-test/topic?type=002&name=男性功能测试',
		share_url:
			'https://diancan-1252107261.cos.accelerate.myqcloud.com/yiliao/F-zaoxie.png',
	},
	{
		type: '003',
		name: '失眠程度测评',
		share_title: '失眠标准自测,测一测你是否身在其中',
		share_path: '/pages/self-test/topic?type=003&name=失眠程度测评',
		share_url:
			'https://diancan-1252107261.cos.accelerate.myqcloud.com/yiliao/F-shimian.png',
	},
];
