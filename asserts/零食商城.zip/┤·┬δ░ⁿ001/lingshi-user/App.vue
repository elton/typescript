<script>
	export default {
		onLaunch: function() {
			wx.cloud.init({
			  env: 'lingshi-user-7gkobalb5f401248',
			  traceUser: true,
			})
		},
		
	}
</script>

<style>
	/*每个页面公共css */
</style>
