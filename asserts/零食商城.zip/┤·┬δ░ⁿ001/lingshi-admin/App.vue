<script>
	export default {
		onLaunch: function() {
			wx.cloud.init({
			  env: 'lingshi-admin-6gvot3wh7e4ac9b5',
			  traceUser: true,
			})
		},
	}
</script>

<style>
	/*每个页面公共css */
</style>
